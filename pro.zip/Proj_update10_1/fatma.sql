use ITIExaminationSystem

----------------------------------PROCEDURE Add_New_Student------------------------------------------
go 
CREATE or alter PROCEDURE Add_New_Student
   
	@first_name varchar(10),
	@last_name varchar(10),
	@age int ,
	@address varchar(50),
	@phone varchar(11),
	@email varchar(30),
	@paswword varchar(20),
    @batch_id int ,
	@userName VARCHAR(20),
	@password NVARCHAR(30)
AS
BEGIN
   if @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
    INSERT INTO [ExamSystem].[Student]([first_name],[last_name],[age],[address],[phone],[email],[password],[batch_id])
    VALUES
	    (@first_name,@last_name,@age,@address,@phone,@email ,@paswword,@batch_id)
        END
	ELSE
	PRINT 'plz enter correct user name or correct password'
END;
go


exec Add_New_Student @first_name='Khadega',@last_name='Alaa',@age=23,@address='talaat streat',@phone='0123349788',@email='khdijaa@iti.gov',@paswword='123456',@batch_id=7 ,@userName='Eng_mrihan',@password='123'


------------------------------------PROCEDURE Edit_student------------------------------------------------------------------
go 
CREATE  or alter PROCEDURE Edit_student
    @id int ,
	@studentFirstName VARCHAR(10),
	@studentLasstName VARCHAR(10),
	@age int ,@address VARCHAR(10),
	@phone varchar(20),
	@email varchar(30),
	@studentPassword NVARCHAR(20),
	@batch_id int ,
	@userName VARCHAR(20),
	@password NVARCHAR(30) 
AS
BEGIN
	IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		UPDATE[ExamSystem].[Student]
		SET first_name = @studentFirstName,
			last_name = @studentLasstName,
			[age]=@age,[address]=@address,
            [phone]=@phone,[email]=@email,
			[password] = @studentPassword,
            [batch_id] = @batch_id
		WHERE id = @id
	END
	ELSE 
		PRINT 'plz enter correct user name or correct password'
END




EXEC  Edit_student
	@id =2,
	@studentFirstName = 'omnia',
	@studentLasstName = 'Mohamed',
	@age =34 ,@address ='talat streat',
	@phone='01014496127',
	@email='fatma@gmail.com',
	@studentPassword='6754',
	@batch_id=1 ,
	@userName ='Eng_mrihan' ,
	@password = '123'


---------------------------------PROCEDURE deletestudent----------------------------------------------
go
CREATE or alter PROCEDURE deletestudent
	@id int,
	@userName VARCHAR(20),
	@password NVARCHAR(30)
AS
BEGIN
	IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		DELETE FROM ITIExam.ExamSys.Student
		WHERE id = @id
	END
	ELSE 
		PRINT 'plz enter correct user name or correct password'
END


	
EXEC deletestudent 
	@id =2,
	@userName = 'Eng_mrihan',
	@password = '123'
------------------------------------------



--------------------------------------------Add_new_instructor--------------------- 

-------------------------------

go 
CREATE or alter PROCEDURE Add_New_instructor
   
	@first_name varchar,
	@last_name varchar,
	@address varchar,
	@phone varchar,
	@salary decimal,
	@age int ,
	@email varchar,
	@paswword varchar,
    @role bit,
	@userName VARCHAR(20),
	@password NVARCHAR(30)

AS
BEGIN
   
   IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
    INSERT INTO [ExamSystem].[Instructor]
    VALUES
	    (@first_name,@last_name,@address,@phone,@salary,@age,@email ,@paswword,@role)
		END
	ELSE
	PRINT 'plz enter correct user name or correct password'
END;
go


exec Add_New_instructor
@first_name='ali',@last_name='mohamed',@address='talaat streat',@phone='010124496127',@salary=3000,@age=32,@email='Ali@gmail.com' ,@paswword='2344',@role=0,@userName='Eng_mrihan',@password=123

---------------------------------PROCEDURE Edit_instructor-------------------------------------------------------------
go 
CREATE or alter PROCEDURE Edit_instructor
   
	@instructorId int,
	@first_name varchar,
	@last_name varchar,
	@address varchar,
	@phone varchar,
	@salary decimal,
	@age int ,
	@email varchar,
	@paswword varchar,
    @role bit,
	@userName VARCHAR(20),
	@password NVARCHAR(30)

AS
BEGIN
     IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		UPDATE[ExamSystem].[Instructor]
		SET first_name = @first_name,
			last_name = @last_name,[salary]=@salary,
			[age]=@age,[address]=@address,
            [phone_number]=@phone,[email]=@email,
			[password] = @paswword,[role]=@role
           
		WHERE id = @instructorId
	END
	ELSE 
		PRINT 'plz enter correct user name or correct password'
        
END;
go


EXEC  Edit_instructor

	@instructorId = '3',
	@first_name = 'Mahmoud',
	@last_name = 'Abd Elkhaleq',
	@salary=3454,
	@age=34,@address='maka',@phone='01224555',
	@paswword = '321',
	@email = 'mahmoud13@iti.gov' ,@role=1,
	@userName ='Eng_Ahmed' ,
	@password = '456'



------------------------------PROCEDURE DeleteInstructor---------------------------------------------------
go 
CREATE or alter PROCEDURE DeleteInstructor
	@id int,
	@userName VARCHAR(20),
	@password NVARCHAR(30)
AS
BEGIN
	IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		DELETE FROM [ExamSystem].[Instructor]
		WHERE id = @id
	END
	ELSE 
		PRINT 'plz enter correct user name or correct password'
END


	
EXEC deletestudent 
	@id =2,
	@userName = 'Eng_mrihan',
	@password = '123'

	go 
---------------------------------PROCEDURE AddTrack--------------------------------------------------

go
CREATE or alter PROCEDURE AddTrack
	@trackName VARCHAR(60),@department_id int ,
	@userName VARCHAR(20),
	@password NVARCHAR(30) 
AS
BEGIN
	if @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		INSERT INTO 
		 [ITIExaminationSystem].ExamSystem.Track
		VALUES (@trackName,@department_id)
	END
	ELSE
	PRINT 'The user name or password is incorrect'
END

 
EXEC AddTrack 
	@trackName = 'DevOps', @department_id=1,
	@userName = 'Eng_mrihan',
	@password = '123'

------------------------------------------PROCEDURE Edittracks-------------------------------------

go 
CREATE PROCEDURE Edittracks
    @id int ,
	@newName VARCHAR(60),@departmentID int ,
	@userName VARCHAR(20),
	@password NVARCHAR(30)
AS
BEGIN
	IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		UPDATE [ITIExaminationSystem].ExamSystem.Track
		SET [name] = @newName , [department_id]=@departmentID
		WHERE id = @id
	END
	ELSE 
		PRINT 'The user name or password is incorrect'
END


EXEC Edittracks 
	@id=1,
	@newName = 'Testing',@departmentID=1,
	@userName = 'Eng_mrihan',
	@password = '123'
--------------------------- PROCEDURE Deletetrack------------------------------------------------------------

create nonclustered index  tracks
on [ExamSystem].[Track]([name])
----
go
CREATE  or alter PROCEDURE Deletetrack
	--@id int , @departmentID int ,
	@name VARCHAR(60), 
	@userName VARCHAR(20),
	@password NVARCHAR(30)
AS
BEGIN
	IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		DELETE FROM [ITIExaminationSystem].ExamSystem.Track
		--WHERE  [id]=@id and [department_id]=@departmentID
		where [name] =@name
	END
	ELSE 
		PRINT 'The user name or password is incorrect'
END


EXEC Deletetrack 
	--@id = 1, @departmentID=1, 
	@name='Testing ',
	@userName = 'Eng_mrihan',
	@password = '123'


---------------------------proc Assign_ExamTo_Student------------------------------------------------------
go 
create or alter proc Add_ExamToStudent
 @student_id int ,
	@examID int, 
	@ExamDate date, 
	@startTime time(7),
	@end_time time(7),
	@userName varchar(20),
	@password varchar(10)
as
begin
if @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		INSERT INTO 
		 [ExamSystem].[Student_Exam]
		VALUES (@student_id,@examID,@ExamDate,@startTime,@end_time)
	END
	ELSE
	PRINT 'The user name or password is incorrect'

end 

exec Add_ExamToStudent 5, 4, '2024-01-16', '10:30:00', '12:30:00','Eng_mrihan','123'


---------------------------PROCEDURE update_examToStudent------------------------------------------------
go 
CREATE PROCEDURE update_examToStudent
    @student_id int ,
	@examID int, 
	@ExamDate date, 
	@startTime time(7),
	@end_time time(7),
	@userName varchar(20),
	@password varchar(10)
AS
BEGIN
	IF @userName = 'Eng_mrihan'
	AND @password = '123'
	BEGIN
		UPDATE [ExamSystem].[Student_Exam]
		SET [student_id] = @student_id , [exam_id]=@examID ,
        [exam_date]=@ExamDate,[start_time]=@startTime
		WHERE [student_id]=@student_id and [exam_id]=@examID
	END
	ELSE 
		PRINT 'The user name or password is incorrect'
END



EXEC update_examToStudent 
	@student_id =1 ,
	@examID =1, 
	@ExamDate ='2024-01-16', 
	@startTime='10:30:00',
	@end_time ='12:00:00',
	@userName = 'Eng_mrihan',
	@password = '123'

-----------------------------------------------------------------------------




-------------------------------PROCEDURE Instructor_SelectStudents_For_Exams----------------------------------------------
go

CREATE OR ALTER PROCEDURE SelectStudentsForExam
    @InstructorID INT,
	@studentID INT,
    @ExamID INT,
	@userName varchar(20),
	@password varchar(10)
AS
BEGIN
    -- Check if the studentID exists in the Student table
    IF NOT EXISTS (SELECT 1 FROM [ExamSystem].[Student] WHERE id = @studentID)
    BEGIN
        PRINT 'Error: Student not found.';
        RETURN;
    END

    -- Check if the ExamID exists in the Exam table
    IF NOT EXISTS (SELECT 1 FROM [ExamSystem].[Exam] WHERE id = @ExamID)
    BEGIN
        PRINT ' Exam not found.';
        RETURN;
    END
	IF @userName = 'Eng_Mohamed'
	AND @password = '456'
	begin
    -- Insert into the Instructor_Student_Exam table
    INSERT INTO [ExamSystem].[Instructor_Student_Exam] (instructor_id, student_id, exam_id)
    VALUES (@InstructorID, @studentID, @ExamID);

    PRINT 'Student selected for the exam successfully.';
	end
	else
	begin 
	        PRINT 'The user name or password is incorrect'
	end 
END;

EXEC SelectStudentsForExam 4,5,4,'Eng_Mohamed','456'

---------------------------------PROCEDURE instructor_Edit_Students_ForExams----------------------------------
go 
CREATE OR ALTER PROCEDURE Edit_StudentsForExam
    @InstructorID INT,
	@studentID INT,
    @ExamID INT,
	@userName varchar(20),
	@password varchar(10)
AS
BEGIN
    -- Check if the studentID exists in the Student table
    IF NOT EXISTS (SELECT 1 FROM [ExamSystem].[Student] WHERE id = @studentID)
    BEGIN
        PRINT 'Error: Student not found.';
        RETURN;
    END

    -- Check if the ExamID exists in the Exam table
    IF NOT EXISTS (SELECT 1 FROM [ExamSystem].[Exam] WHERE id = @ExamID)
    BEGIN
        PRINT ' Exam not found.';
        RETURN;
    END
	IF @userName = 'Eng_Mohamed'
	AND @password = '456'
	BEGIN
		UPDATE [ExamSystem].[Instructor_Student_Exam]
		SET [student_id] = @studentID , [exam_id]=@examID ,
        [instructor_id]=@InstructorID
		WHERE [student_id]=@studentID and [exam_id]=@examID
	END
	ELSE 
		PRINT 'The user name or password is incorrect'
    
    

    PRINT 'Student selected for the exam successfully.';
END;


exec Edit_StudentsForExam 4,5,4,'Eng_Mohamed','456'


--------------------------------------PROC_TO_SHOW_EXAM_DETAILS__DATE---------------------------------------
go

CREATE or alter PROCEDURE DisplayExamDetails
    @StudentID INT,
    @ExamID INT
AS
BEGIN
    SELECT
	    se.student_id,
        e.type,
        se.exam_date,
        se.start_time,
        se.end_time
      
    FROM
      [ExamSystem].[Student_Exam] se
    JOIN
       [ExamSystem].[Exam] e ON se.exam_id = e.id
    WHERE
        se.student_id = @StudentID
        AND se.exam_id = @ExamID;
    
END;

exec DisplayExamDetails 1,4

------------------------------------------Student_take_Exam---------------------------------------------------
go 
CREATE OR ALTER PROCEDURE CheckExamAccess
    @StudentID INT,
    @ExamID INT
AS
BEGIN
    DECLARE @CurrentDateTime DATETIME = GETDATE();
    DECLARE @CurrentTime TIME = CONVERT(TIME, @CurrentDateTime);

    IF EXISTS (
        SELECT 1
        FROM [ExamSystem].[Student_Exam]
        WHERE  [student_id]= @StudentID
            AND [exam_id] = @ExamID
            AND [exam_date] = CONVERT(DATE, @CurrentDateTime) -- Ensure the exam is on the current date
            AND @CurrentTime BETWEEN  [start_time]AND end_time
    )
    BEGIN
        DECLARE @content VARCHAR(MAX);


DECLARE display_question_cursor CURSOR FOR
SELECT [content] 
FROM [ExamSystem].[Question] q inner join [ExamSystem].[Exam_Question] eS on q.id=eS.question_id;


OPEN display_question_cursor;


FETCH NEXT FROM display_question_cursor INTO @content;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @content;
    FETCH NEXT FROM display_question_cursor INTO @content;
END;

        PRINT 'You have access to the exam.';
       
    END
    ELSE
    BEGIN
        
        PRINT 'You do not have access to the exam at the moment.';
       
    END
END;


exec CheckExamAccess 5,4




----------------------------------PROCEDURE that add and store_new_answer------------------------------------
go
CREATE OR ALTER PROCEDURE StoreStudentAnswer
    @StudentID INT,
    @ExamID INT,
    @QuestionID INT,
    @StudentResponse VARCHAR(250),
	@userName varchar(20),
	@password varchar(20)
AS
BEGIN
     
    IF @userName = 'fatima'
	AND @password = '789'
	BEGIN
    INSERT INTO [ExamSystem].[Student_Answer] (student_id, exam_id, question_id, [student_response])
    VALUES (@StudentID, @ExamID, @QuestionID, @StudentResponse);
	end

else 
      begin
	  print 'sorry, you canot stored new answer , for sudents only !!! '
	  end
END;
go

EXEC StoreStudentAnswer 3, 1, 5, 'f','fatima','789'

-----------------------------------------PROCEDURE update_student_answer----------------------------------
go 
CREATE PROCEDURE update_student_answer
     @StudentID INT,
    @ExamID INT,
    @QuestionID INT,
    @StudentResponse VARCHAR(250),
	@userName varchar(20),
	@password varchar(20)
AS
BEGIN
	IF @userName = 'fatima'
	AND @password = '789'
	BEGIN
		UPDATE ITIExaminationSystem.ExamSystem.Student_Answer

		SET [student_id]=@StudentID,[question_id]=@QuestionID,
        [exam_id]=@ExamID,[student_response]=@StudentResponse

		where [student_id]=@StudentID and [exam_id]=@ExamID and [question_id]=@QuestionID
	END
	ELSE 
		PRINT 'sorry, you canot stored  answer , Allow for sudents only !!!'
END


EXEC update_student_answer 
    @StudentID =1,
    @ExamID =1,
    @QuestionID =1,
    @StudentResponse ='T',
	@userName ='fatima',
	@password ='789'
	


----------------------------------------proc_deleteAnswer by student-----------------------------------------
 go 
 create or alter proc Delete_Answer
 @studentID int ,
 @userName varchar(20),
 @password varchar(20)

 as 
 begin
     IF @userName = 'fatima'
	AND @password = '789'
	BEGIN
    delete from
	[ExamSystem].[Student_Answer]
	where [student_id]=@StudentID
	end 

    else 
      begin
	  print 'sorry, you canot delete answer ,Allow for sudents only '
      end 
end 
 
 exec Delete_Answer 1,'fatima','789'


---------------------------------------FUNCTION CalculateCorrectAnswers---------------------------------


--DROP PROCEDURE IF EXISTS CalculateCorrectAnswers;
go 

CREATE OR ALTER FUNCTION CalculateCorrectAnswers
(@StudentID INT, @ExamID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT
        s.[student_id],
        s.[exam_id],
        COALESCE(SUM(CASE WHEN UPPER(s.[student_response]) = UPPER(q.[correct_answer]) THEN 1 ELSE 0 END), 0) AS CorrectAnswersCount
    FROM
       ITIExaminationSystem.ExamSystem.Student_Answer s
    JOIN
        ITIExaminationSystem.ExamSystem.Question q ON s.[question_id] = q.id
    WHERE
        s.[student_id] = @StudentID
        AND s.[exam_id] = @ExamID
    GROUP BY
        s.[student_id], s.[exam_id]
);


SELECT *
FROM CalculateCorrectAnswers(2,4)

---------------------------------------------trigger prevent_instructor_from_update----------------------------


--drop trigger  prevent_instructor_from_update
go
 create trigger  prevent_instructor_from_update
 on [ExamSystem].[Instructor]
 instead of update
 as
 print 'sorry, not allowed for updating '

update [ExamSystem].[Instructor]
set first_name='jana'
where id=1;
------------------

------------------------------------------------------create nonclustered by student name----------------------
create nonclustered index student_firstname
on [ExamSystem].[Student](first_name)

select * from [ExamSystem].[Student] where [first_name]='Fatma'

--drop index  student_firstname on students

----------------------------------------------------------------index by instructor name----------------------
create nonclustered index  instructor_firstname
on [ExamSystem].[Instructor]([first_name])

select * from [ExamSystem].[Instructor] where [first_name]='Hassan'


-------------------------------------------------------------------index by course name-------------------------------------------------------------------
create nonclustered index course_name
on [ExamSystem].[Course](name)

select * from [ExamSystem].[Course] where name='HTML'

--------------------------------------------------------
go
create view show_all_instrucrors_courses  as  -----------------------show_all_instrucrors_courses
select first_name,last_name, s.name  ,[description]
from  [ExamSystem].[Instructor],[ExamSystem].[Instructor_Course] inco,[ExamSystem].[Course] s
where [ExamSystem].[Instructor].id=inco.course_id
go

select * from show_all_instrucrors_courses
order by first_name;

----drop view show_all_instrucrors_courses

-------------------------------------------------------


