------question 
-- add_question Execution
-- add_question Execution Q1 course 1 , instructor 1

-- add_question Execution Q2 
SELECT * FROM QuestionView
GO
EXEC add_question 
    @question_type = 'MCQ',
    @question_content = 'Which HTML element is used to define the structure of an HTML document? A) <header> B) <body> C) <html> D) <section>',
    @correct_answer = 'c',
    @course_id = 1,
    @instructor_id = 3;
GO
-- add_question Execution Q3 course 1 , instructor 1
SELECT * FROM QuestionView
GO
EXEC add_question 
    @question_type = 'T|F',
    @question_content = 'HTML stands for "Hyper Text Markup Language."',
    @correct_answer = 'T',
    @course_id = 1,
    @instructor_id = 3;
GO
-- add_question Execution 
SELECT * FROM QuestionView
GO
EXEC add_question 
    @question_type = 'T|F',
    @question_content = 'The <div> tag is used to define a hyperlink in HTML',
    @correct_answer = 'F',
    @course_id = 1,
    @instructor_id = 3;

	-- edit_question Execution
	EXEC edit_question  @question_type = "T|F",
	@question_body = "SQL Stands For Structure Query Language",
	@correct_answer = "T", @course_id = 1, 
	@instructor_id = 3 ,@question_id = 1


-- delete_question Execution
-- delete_question Execution Q2 course 1 , instructor 1
GO
EXEC delete_question @course_id = 1, 
	@instructor_id = 3 ,@question_id = 4
GO





-- select_question_manually execution 
EXEC select_question_manually @instructor_id = 3,
	@course_id = 1,@question_id = 3

-- select_random_questions execution 
EXEC select_random_questions @instructor_id = 3,
	@course_id = 1 , @Question_type = "T|F",
	@number_of_questions = 3

-- show_my_questions execution 
EXEC	show_my_questions 
        @instructor_id = 3
go

-----create_exam

DECLARE @questions questions_manually_table
INSERT INTO @questions VALUES                       ---test i=3 , c=1,e=1002
(1, 40), (2, 40);

EXEC select_questions_manually
	@instructor_id = 3, @course_id = 1, @exam_id = 1002,
	@questions_table = @questions;


-- select_random_questions execution 
EXEC select_questions_randomly
	@instructor_id = 5, @course_id = 1, @exam_id = 1,
	@number_of_tf = 2, @degree_of_tf = 20,
	@number_of_mcq = 1, @degree_of_mcq = 40,
	@number_of_text = 0, @degree_of_text = 10;


---------

exec Add_ExamToStudent 5, 4, '2024-01-16', '10:30:00', '12:30:00','Eng_mrihan','123'
EXEC SelectStudentsForExam 4,5,4,'Eng_Mohamed','456'
exec Edit_StudentsForExam 4,5,4,'Eng_Mohamed','456'
select * from show_all_instrucrors_courses
order by first_name;


EXEC update_examToStudent 
	@student_id =1 ,
	@examID =1, 
	@ExamDate ='2024-01-16', 
	@startTime='10:30:00',
	@end_time ='12:00:00',
	@userName = 'Eng_mrihan',
	@password = '123'

exec Add_ExamToStudent 5, 4, '2024-01-16', '10:30:00', '12:30:00','Eng_mrihan','123'


