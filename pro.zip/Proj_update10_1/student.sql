----student 

exec DisplayExamDetails 1,4   ---or(5,4)

exec CheckExamAccess 5,4     -----takeExam if in specific time 

EXEC StoreStudentAnswer 3, 1, 5, 'f','fatima','789'  ---or(2,4,1,f)

EXEC update_student_answer       ---or(2,4,1,f)
    @StudentID =1,
    @ExamID =1,
    @QuestionID =1,
    @StudentResponse ='T',
	@userName ='fatima',
	@password ='789'
	

exec Delete_Answer 1,'fatima','789'      ---or(2,4,1,f)



SELECT * FROM CalculateCorrectAnswers(2,4)    

EXEC calculate_result @StudentID = 2, @ExamID = 4;

SELECT * FROM RESULTS