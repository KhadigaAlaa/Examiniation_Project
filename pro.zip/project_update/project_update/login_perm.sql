----Admin
CREATE LOGIN Mostapha  
WITH PASSWORD = 'm1234';  

USE ITIExaminationSystem
CREATE USER Mostapha FOR LOGIN Mostapha;  
GO

CREATE ROLE SystemAdmin ;
ALTER ROLE SystemAdmin ADD MEMBER Mostapha

-- Grant ALTER ANY LOGIN permission to a user
GRANT ALTER ANY LOGIN TO Mostapha ;
-- Grant SHUTDOWN permission to a user
GRANT SHUTDOWN TO Mostapha;

------------------------------------------------------------------

CREATE ROLE Trainning_manager ;
ALTER ROLE Trainning_manager ADD MEMBER Eng_mrihan

-- Create An Trainning Manager LogIn. 
CREATE LOGIN Eng_mrihan  
WITH PASSWORD = '123';  

USE ITIExaminationSystem
CREATE USER Eng_mrihan FOR LOGIN Eng_mrihan;  
GO
----------------------------------------------------------------------


CREATE ROLE Instructor ;
ALTER ROLE Instructor ADD MEMBER Eng_Mohamed

-- Create An Instructor LogIn.  
CREATE LOGIN Eng_Mohamed  
WITH PASSWORD = '456';  

USE ITIExaminationSystem
CREATE USER Eng_Mohamed FOR LOGIN Eng_Mohamed;  


---------------------------------------------------

CREATE ROLE Student ;
ALTER ROLE Student ADD MEMBER fatima

-- Create A Student LogIn.  
CREATE LOGIN fatima  
WITH PASSWORD = '789';  

USE ITIExaminationSystem
CREATE USER fatima FOR LOGIN fatima;  


-----------------------------------------------------------------------------
--  Permissions As A Training Manager
-- Can Add , Edit And Delete ( Brances , Tracks
-- Intack, Students , Instructores , Courses,
-- Instructore_courses) tables
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Batch]TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Branch]TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Track]TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON [ExamSystem].[Intake] TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON [ExamSystem].[Student] TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Instructor]TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Course]TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Instructor_Course]TO Eng_mrihan;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[ExamSystem].[Department]TO Eng_mrihan;




GRANT EXEC ON OBJECT :: [dbo].[Add_New_Student]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[Edit_student]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[deletestudent]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[Add_New_instructor]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[Edit_instructor]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[DeleteInstructor]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[AddTrack]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[Edittracks]TO Eng_mrihan
GRANT EXEC ON OBJECT :: [dbo].[Deletetrack]TO Eng_mrihan
GRANT SELECT ON [dbo].[show_all_instrucrors_courses] TO YourUserName;        --view 



GRANT EXEC ON OBJECT ::   [dbo].[editstudents]TO Eng_mrihan;
GRANT EXEC ON OBJECT ::  [dbo].[deletestudent]TO Eng_mrihan;
GRANT EXEC ON OBJECT :: [dbo].[add_course]TO Eng_mrihan;
GRANT EXEC ON OBJECT ::  [dbo].[edit_Courses]  TO Eng_mrihan;
GRANT EXEC ON OBJECT :: [dbo].[delete_course] TO Eng_mrihan;
GRANT EXEC ON OBJECT :: [dbo].[dbo].[add_branch] TO Eng_mrihan;
GRANT EXEC ON OBJECT :: [dbo].[dbo].[edit_branches]  TO Eng_mrihan;
GRANT EXEC ON OBJECT :: [dbo].[dbo].[delete_branch]  TO Eng_mrihan;



--  Permissions As Instructor Can Add , Edit and Delete
-- in ( exam , exam_question , question_pool) Tables , 
GRANT INSERT,UPDATE,DeLETE ON [ExamSystem].[Exam]TO Eng_Mohamed;
GRANT INSERT,UPDATE,DeLETE ON [ExamSystem].[Exam_Question] TO Eng_Mohamed;
GRANT INSERT,UPDATE,DeLETE ON  [ExamSystem].[Question]TO Eng_Mohamed;
--REVOKE INSERT,UPDATE,DeLETE ON SCHEMA::dbo TO Eng_Mohamed;

GRANT EXEC ON OBJECT ::  [dbo].[SelectStudentsForExam] TO Eng_Mohamed;
GRANT EXEC ON OBJECT :: [dbo].[Edit_StudentsForExam]TO Eng_Mohamed
GRANT EXEC ON OBJECT :: [dbo].[Add_ExamToStudent]TO Eng_Mohamed
GRANT EXEC ON OBJECT :: [dbo].[update_examToStudent]TO Eng_Mohamed



----system 
--[dbo].[CalculateCorrectAnswers]






-- Permissions As Instructor Can Add, Edit , Delete
-- select random question, select question manually 
-- and show questions (To His Courses Only)
GRANT EXEC ON OBJECT :: [dbo].[add_question]TO Eng_Mohamed;
GRANT EXEC ON OBJECT :: [dbo].[edit_question] TO Eng_Mohamed;
GRANT EXEC ON OBJECT :: [dbo].[delete_question] TO Eng_Mohamed;
GRANT EXEC ON OBJECT :: [dbo].[select_question_manually] TO Eng_Mohamed;
GRANT EXEC ON OBJECT :: [dbo].[select_random_questions] TO Eng_Mohamed;
GRANT EXEC ON OBJECT :: [dbo].[show_my_questions]  TO Eng_Mohamed;



-----Students

GRANT EXEC ON OBJECT :: [dbo].[StoreStudentAnswer]TO fatima;
GRANT EXEC ON OBJECT :: [dbo].[update_student_answer]TO fatima;
GRANT EXEC ON OBJECT :: [dbo].[Delete_Answer]TO fatima;
GRANT EXEC ON OBJECT :: [dbo].[CheckExamAccess]TO fatima;
GRANT EXEC ON OBJECT :: [dbo].[DisplayExamDetails]TO fatima;






