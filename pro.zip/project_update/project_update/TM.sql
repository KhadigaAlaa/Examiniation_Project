---TM
-- add_branch execution 
EXEC add_branch 
	@branchName = 'Assiut',
	@userName = 'Eng:Ahmed',
	@password = '456'


-- edit_branches execution 
EXEC edit_branches 
	@oldName = 'Sohag',
	@newName = 'Qena',
	@userName = 'Eng:Ahmed',
	@password = '456'

-- delete_branch execution 
EXEC delete_branch 
	@name = 'Assiut',
	@userName = 'Eng:Ahmed',
	@password = '456'

--------------------------------------------------- COURSES (ADD, EDIT,DELETE) -------------------------------------------------
-- Use function to show the Instructor's Course Data
GO
DECLARE @userName VARCHAR(20) = 'Eng:Ahmed'
DECLARE @password NVARCHAR(30) = '456'
SELECT * FROM GetCourseInstructorData(@userName, @password, 4)


-- add_course execution 
EXEC add_course 
	@courseName = 'Java Script',
	@minDegree = 65,
	@maxDegree =  100,
	@userName = 'Eng:Ahmed',
	@password = '456',
	@instructor_id = 3

EXEC add_course 
	@courseName = 'HTML',
	@minDegree = 65,
	@maxDegree =  100,
	@userName = 'Eng:Ahmed',
	@password = '456',
	@instructor_id = 3


-- edit_Courses execution 

EXEC edit_Courses 
	@courseId= 1,
	@courseName = 'SQL',
	@courseDescription = 'Learn About Microsoft SQL Server',
	@minDegree = 65 ,
	@maxDegree = 100,
	
	@userName ='Eng:Ahmed' ,
	@password = '456',
	@instructor_id = 3


--EXEC edit_Courses 
--	@courseId= 8,
--	@courseName = 'JavaScript',
--	@courseDescription = 'Learn about dynamic web development',
--	@maxDegree = 100,
--	@minDegree = 65 ,
--	@userName ='Eng:Ahmed' ,
--	@password = '456',
--	@instructor_id = 4

-- delete_course execution 
EXEC delete_course 
	@courseId = 13,
	@userName = 'Eng:Ahmed',
	@password = '456'


SELECT * FROM students_personal_data

	
SELECT * FROM QuestionView;


EXEC Deletetrack 
	--@id = 1, @departmentID=1, 
	@name='Testing ',
	@userName = 'Eng_mrihan',
	@password = '123'

	EXEC Edittracks 
	@id=1,
	@newName = 'Testing',@departmentID=1,
	@userName = 'Eng_mrihan',
	@password = '123'

	EXEC AddTrack 
	@trackName = 'DevOps', @department_id=1,
	@userName = 'Eng_mrihan',
	@password = '123'


	EXEC deletestudent 
	@id =2,
	@userName = 'Eng_mrihan',
	@password = '123'


	EXEC  Edit_instructor

	@instructorId = 3,
	@first_name = 'Mahmoud',
	@last_name = 'Abd Elkhaleq',
	@salary=3454,
	@age=34,@address='maka',@phone='01224555',
	@paswword = '321',
	@email = 'mahmoud13@iti.gov' ,@role=1,
	@userName ='Eng_mrihan' ,
	@password = '123'

	exec Add_New_instructor
	@first_name='ali',@last_name='mohamed',
	@address='talaat streat',@phone='010124496127',
	@salary=3000,@age=32,@email='ali@gmail.com' ,
	@paswword='2344',@role=0,@userName='Eng_mrihan',@password=123


	EXEC deletestudent 
	@id =2,
	@userName = 'Eng_mrihan',
	@password = '123'



	EXEC  Edit_student
	@id =2,
	@studentFirstName = 'omnia',
	@studentLasstName = 'Mohamed',
	@age =34 ,@address ='talat streat',
	@phone='01014496127',
	@email='fatma@gmail.com',
	@studentPassword='6754',
	@batch_id=1 ,
	@userName ='Eng_mrihan' ,
	@password = '123'



	exec Add_New_Student @first_name='Khadega',@last_name='Alaa',
	@age=23,@address='talaat streat',@phone='0123349788',
	@email='dejaa@iti.gov',
	@paswword='123456',@batch_id=1,@userName='Eng_mrihan',
	@password='123'


	SELECT * FROM Students_Batch